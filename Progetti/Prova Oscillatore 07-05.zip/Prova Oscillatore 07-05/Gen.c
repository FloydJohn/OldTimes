/************************************************************

Gruppo : Martinelli Racheli Macchini

Classe : 4D

Data   : 16/04/2013

Titolo : Oscillatore con frequenza variabile

PIC    : 16F88

Descrizione : Questo oscillatore varier� la frequenza in uscita
tramite la lettura di pulsanti esterni.
Le frequenze possibili saranno :
SW1 - 100 Hz
SW2 - 1   kHz
SW3 - 10  kHz
SW4 - 100 kHz

************************************************************/
#include <xc.h>
#include <pic.h>

#define SW1 RA0
#define SW2 RA1
#define SW3 RA2
#define SW4 RA3
#define OUT RA4

#pragma config CONFIG1 = 0x3F62;
#pragma config CONFIG2 = 0x3;

#define _XTAL_FREQ 20000000


void main(void) {

ANSEL = 0;
CMCON=0X07;
TRISA = 0x0F;
OUT=1;

while(1){

if      (SW1) __delay_us(9998.5);
else if (SW2) __delay_us(997.4);
else if (SW3) __delay_us(96.4);
else if (SW4) __delay_us(5.54);

OUT = !OUT;

}
}